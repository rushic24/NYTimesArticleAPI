from .search_api import *

__version__ = "1.1.0"
__author__ = "Rushi Chaudhari (@rushic24)"
__all__ = ["articleAPI"]

if __name__ == "__main__":
    print("This module cannot be run on its own. Please use by running ",
          "\"from nytimesarticlev2 import articleAPI\"")
    exit(0)
